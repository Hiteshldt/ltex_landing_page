function Products() {
  const colorways = [
    { name: "Caramel Brown", hex: "#8B5230", desc: "A warm tobacco tone for heritage accessory lines." },
    { name: "Chocolate Brown", hex: "#3F2618", desc: "Deep cocoa for outerwear and structured goods." },
    { name: "Natural Tan Beige", hex: "#C9A37A", desc: "Untreated, neutral — finishes beautifully." },
    { name: "Cognac Amber", hex: "#A85A1F", desc: "Warm orange-brown for footwear and bags." },
    { name: "Espresso Black", hex: "#1A1614", desc: "Dense and architectural for premium fashion." },
  ];

  return (
    <section id="products">
      <div className="container">
        <SectionHead
          code="03 / Products"
          label="Material library"
          title={<>Premium swatches, made <span className="green-word">to spec.</span></>}
          subtitle="Five stock colorways for our vegan banana leather, with custom matching available. Every swatch is vegan-certified and traceable to a specific FPO cluster — sample kits ship within five business days."
        />

        <Reveal>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 16 }} className="swatch-grid">
            {colorways.map((c, i) => (
              <div key={c.name} className="card outline" style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
                <div style={{ aspectRatio: "3/4", background: c.hex, position: "relative" }}>
                  <div style={{
                    position: "absolute", top: 12, left: 12, right: 12,
                    background: "rgba(255,255,255,0.95)", borderRadius: 6,
                    padding: "8px 10px", display: "flex", alignItems: "baseline", justifyContent: "space-between",
                  }}>
                    <Wordmark size={13} />
                    <span className="label-mono" style={{ fontSize: 9 }}>{(i + 1).toString().padStart(2, "0")} / 05</span>
                  </div>
                </div>
                <div style={{ padding: "16px 18px 18px" }}>
                  <div style={{ fontWeight: 700, fontSize: 15, color: "var(--ink)" }}>{c.name}</div>
                  <div className="label-mono" style={{ marginTop: 6 }}>Banana Leather · Vegan Certified</div>
                  <p className="body-s" style={{ marginTop: 10, marginBottom: 0 }}>{c.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </Reveal>

        {/* Big Leaf-Guard hero spread */}
        <Reveal>
          <div style={{
            marginTop: 48,
            display: "grid",
            gridTemplateColumns: "1.1fr 1fr",
            gap: 0,
            border: "1px solid var(--rule)",
            borderRadius: 16,
            overflow: "hidden",
            background: "#fff",
          }} className="lg-spread">
            <div style={{ padding: 0, borderRight: "1px solid var(--rule)" }}>
              <ImgPlaceholder
                code="LEAF-GUARD / DEMO"
                ratio="5 / 4"
                prompt="Side-by-side comparison: two glass bowls of strawberries on white surface. Left labeled 'UNCOATED (DAY 7)' — strawberries are wilted, dull. Right labeled 'LEAF-GUARD COATED (DAY 7)' — strawberries are bright, plump, glossy. Bright clean food photography. Subtle inset diagram showing molecular coating layer. Matches deck visual."
                style={{ borderRadius: 0, border: "none" }}
              />
            </div>
            <div style={{ padding: "40px 36px", display: "flex", flexDirection: "column", justifyContent: "center", gap: 20 }}>
              <span className="chip chip-green"><span className="dot" /> Pilot programs open</span>
              <h3 className="display-m" style={{ margin: 0 }}>
                <span style={{ color: "var(--ink)" }}>Leaf-Guard™</span><br />
                <span className="green-word">+40–60%</span> shelf life.
              </h3>
              <p className="body" style={{ margin: 0, maxWidth: "44ch" }}>
                A starch-based edible coating extracted from banana pith. Applied as a fine spray at the packhouse, it forms a transparent, food-safe barrier — no taste, no aftertaste, no plastic.
              </p>
              <ul className="check-list">
                <li>Tested on mango, avocado, banana, strawberry</li>
                <li>Food-safe, FDA-pathway compliant</li>
                <li>Drop-in for existing packhouse equipment</li>
              </ul>
              <div>
                <a href="#contact" className="btn btn-green" style={{ marginTop: 8 }}>Start a pilot <span className="arrow">→</span></a>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
      <style>{`
        @media (max-width: 1100px) { .swatch-grid { grid-template-columns: repeat(3, 1fr) !important; } }
        @media (max-width: 720px) { .swatch-grid { grid-template-columns: repeat(2, 1fr) !important; } }
        @media (max-width: 900px) {
          .lg-spread { grid-template-columns: 1fr !important; }
          .lg-spread > div:first-child { border-right: none !important; border-bottom: 1px solid var(--rule); }
        }
      `}</style>
    </section>
  );
}

window.Products = Products;
